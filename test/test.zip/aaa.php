<?php
/*foreach($_POST['title'] as $k=>$v){
    $ar[]=array($v,$_POST['user'][$k],$_POST['note'][$k]);
}
print_r($ar);


foreach( $_POST['name'] as $value ) {
echo $value;
}*/

var_dump($_POST);
?>